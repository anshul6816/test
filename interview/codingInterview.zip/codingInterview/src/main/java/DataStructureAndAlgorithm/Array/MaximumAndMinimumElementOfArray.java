package DataStructureAndAlgorithm.Array;

import java.util.Arrays;

public class MaximumAndMinimumElementOfArray {

	/*
	 * Input: arr[] = {3, 5, 4, 1, 9} Output: Minimum element is: 1 Maximum element
	 * is: 9
	 * 
	 * Input: arr[] = {22, 14, 8, 17, 35, 3} Output: Minimum element is: 3 Maximum
	 * element is: 35
	 */

	public static void main(String[] args) {

		int arr[] = { 22, 14, 8, 17, 35, 3 };

		//..................................METHOD 1.......................................................
		int maxValue = 0;
		int minValue = 0;

		for (int i = 0; i < arr.length; i++) {

			if (maxValue < arr[i]) {
				maxValue = arr[i];
			}

			minValue = maxValue;
			if (minValue > arr[i]) {
				minValue = arr[i];
			}
		}

		minValue = maxValue;
		for (int i = 0; i < arr.length; i++) {

			if (minValue > arr[i]) {
				minValue = arr[i];
			}
		}

		System.out.println("Maximum Value: " + maxValue);
		System.out.println("Minimum Value: " + minValue);
		
		
		
		//..................................METHOD 2.......................................................
		Arrays.sort(arr);
		int len= arr.length;
		System.out.println("Min: " +  arr[0]       );
		System.out.println("Max: " +  arr[len-1]   );
	}
}
