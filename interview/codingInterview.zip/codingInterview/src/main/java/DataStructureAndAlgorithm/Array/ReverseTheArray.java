package DataStructureAndAlgorithm.Array;

/*	Input :  arr[] = {4, 5, 1, 2}
	Output : arr[] = {2, 1, 5, 4}
*/

public class ReverseTheArray {

	public static void main(String[] args) {

		int arr[] = { 4, 5, 9, 1, 2 };
//...................................METHOD 1.....................................................................
		int len = arr.length;
		int reverseArr[] = new int[len];

		for (int i = len - 1; i >= 0; i--) {
			reverseArr[i] = arr[i];
//			  System.out.println(reverseArr[i]);
		}

//...................................METHOD 2 (Better).....................................................................		  
		int start = 0;
		int end = arr.length - 1;
		int temp = 0;
		while(start < end) {
			temp = arr[start];
			arr[start] = arr[end];
			arr[end] = temp;
			start++;
			end--;

		}
		
		for(int i:arr) {
			System.out.println(i);
		}
	}
}
