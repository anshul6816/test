package DataStructureAndAlgorithm.Array;

/*
Example 1:

Input: nums = [-2,1,-3,4,-1,2,1,-5,4]
Output: 6
Explanation: The subarray [4,-1,2,1] has the largest sum 6.
Example 2:

Input: nums = [1]
Output: 1
Explanation: The subarray [1] has the largest sum 1.
Example 3:

Input: nums = [5,4,-1,7,8]
Output: 23
Explanation: The subarray [5,4,-1,7,8] has the largest sum 23.
*/

// KADANE'S Algorithm----
// Reference-------> https://leetcode.com/problems/maximum-subarray/solutions/1595097/java-kadane-s-algorithm-explanation-using-image/
//		    -------> https://www.youtube.com/watch?v=HCL4_bOd3-4

public class SubArrayWithLargestSum {

	public static void main(String[] args) {
		int[] nums = { -2, 1, -3, 4, -1, 2, 1, -5, 4 };
		int current_sum = 0;
		int max_sum = Integer.MIN_VALUE;

		int start_pos = 0;
		int end_pos = 0;
		int temp_pos = 0;
		for (int i = 0; i < nums.length; i++) {

			current_sum += nums[i];
//        	max_sum = Math.max(current_sum,max_sum);

			if (current_sum > max_sum) {
				max_sum = current_sum;
				start_pos = temp_pos;
				end_pos = i;
			}

			if (current_sum < 0) {
				current_sum = 0;
				temp_pos = i + 1;
			}
		}
		System.out.println("maximum sum: " + max_sum);

		for (int i = start_pos; i <= end_pos; i++) {
			System.out.print(nums[i] + " ");
		}
	}

}
