package com.codingInterview.String;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class NumberStartsFrom1 {

	public static void main(String[] args) {
		
		List<Integer> asList = Arrays.asList(10,50,16,78,64,11,10);
		
		
		List<String> numberList = asList.stream().map( n -> n+"")
					   							 .filter( s-> s.startsWith("1"))
					   							.collect(Collectors.toList());
		
		System.out.println(numberList);
	}
}
