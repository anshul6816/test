package com.codingInterview.String;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class SortedStringList {

	public static void main(String[] args) {

		List<String> myList= Arrays.asList("Tushar","Divar","Ketaki","San","Pra","Anshu");
		myList.stream().sorted(Collections.reverseOrder()).forEach(System.out::println);
		
	}

}
