package com.codingInterview.String;

public class ReverseUsingStringBuffer {

	public static void main(String[] args) {
		
		StringBuffer name= new StringBuffer("Tushar");
		String reverseName= name.reverse()
								.toString();
		
		System.out.println(reverseName);

	}

}
