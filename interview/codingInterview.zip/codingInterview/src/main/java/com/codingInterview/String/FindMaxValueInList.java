package com.codingInterview.String;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class FindMaxValueInList {
	
	public static void main(String[] args) {
		
		List<Integer> asList = Arrays.asList(13,5,546,8,13,1,35,4);
		int maxValue = asList.stream()
									  .max(Integer::compare)
									  .get();
		
		//--------------Second Method---------------------------------------
//		int maxVal = asList.stream().sorted(Collections.reverseOrder()).findFirst().get();
		
		
		System.out.println(maxValue);
	}

}
