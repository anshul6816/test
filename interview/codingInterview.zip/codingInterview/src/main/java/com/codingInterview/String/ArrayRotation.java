package com.codingInterview.String;

import java.util.Collections;

public class ArrayRotation {
	public static void main(String[] args) {
		int[] arr= new int[] {-2,-1,-7,5,6,8,1,3};
		
		int len= arr.length;
	
		int[] tempArr= new int[4];
		
		for(int i=0;i<4;i++) {
		tempArr[i]= 	
		}
	}

}
