package com.codingInterview.lambda;

@FunctionalInterface
interface checkEmptyString{
	boolean checkEmpty(String s);
}


public class CheckStringEmptyOrNot {

	public static void main(String[] args) {

		checkEmptyString check= (s) -> s.isEmpty();
		
		boolean b1 = check.checkEmpty("sdfsd");
		boolean b2= check.checkEmpty("");
		
		System.out.println(b1);
		System.out.println(b2);
		
		
	}

}
