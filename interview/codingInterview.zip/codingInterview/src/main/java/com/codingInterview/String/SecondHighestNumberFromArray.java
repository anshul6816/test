package com.codingInterview.String;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class SecondHighestNumberFromArray {

	public static void main(String[] args) {
		
List<Integer> numbersList= Arrays.asList(6,3,4,2,1,7,8,9);
									   
	 Optional<Integer> findFirst = numbersList.stream()
											.sorted(Collections.reverseOrder())
											.skip(1)
											.findFirst();
	 Integer secondHighestNumber = findFirst.get();

	 System.out.println(numbersList);
	 
		System.out.println(secondHighestNumber);
	
	}
}
