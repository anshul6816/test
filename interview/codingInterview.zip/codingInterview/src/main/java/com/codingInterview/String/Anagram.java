package com.codingInterview.String;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Anagram {

	public static void main(String[] args) {
		String s1= "William Shakespeare";
		s1= s1.toLowerCase();
		s1=s1.replaceAll(" ", "");
		
		String s2= "I am a weakish speller";
		s2= s2.toLowerCase();
		s2=s2.replaceAll(" ", "");
		
		Map<Character, Long> s1Map = s1.chars()
									   .mapToObj(ch -> (char)ch)
									   .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));		

		Map<Character, Long> s2Map = s2.chars()
									   .mapToObj(ch -> (char)ch)
									   .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));		

		System.out.println(s1Map);
		System.out.println(s2Map);
		
		System.out.println(s1Map.equals(s2Map));
	}

}





