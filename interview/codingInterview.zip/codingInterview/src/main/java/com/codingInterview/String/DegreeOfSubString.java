package com.codingInterview.String;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class DegreeOfSubString {

	public static void main(String[] args) {

		String s = "1046555544797711111113333399";
		List<Character> numList = s.chars().mapToObj(c -> (char) c).collect(Collectors.toList());

		System.out.println(numList);
		Map<Character, Long> collect = numList.stream()
												.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		Long maxDegreeOfArray = collect.values().stream().max(Long::compare).get();
		Long minDegreeOfArray = collect.values().stream().min(Long::compare).get();

		Map<Character, Long> elementWithMaxDegree = collect.entrySet().stream()
																		.filter(m -> m.getValue() == maxDegreeOfArray)
																		.collect(Collectors.toMap(k -> k.getKey(), v -> v.getValue()));

		Map<Character, Long> elementWithMinDegree = collect.entrySet().stream()
																		.filter(m -> m.getValue() == minDegreeOfArray)
																		.collect(Collectors.toMap(k -> k.getKey(), v -> v.getValue()));

		System.out.println("Element with max degree: " + elementWithMaxDegree);
		System.out.println("Element with min degree: " + elementWithMinDegree);
	}

}
