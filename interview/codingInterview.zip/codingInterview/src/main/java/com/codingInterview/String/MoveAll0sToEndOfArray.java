package com.codingInterview.String;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class MoveAll0sToEndOfArray {

	public static void main(String[] args) {
		int[] numberArray = new int[] { 0, 5, 3, 0, 4, 0, 9, 7, 5, 0, 7, 0, 1, 0, 0, 3, 0 };

		Arrays.sort(numberArray);	// sort the array
	
		List<Integer> sortedList= new LinkedList();		
		for(int i: numberArray) {
			sortedList.add(i);				// store element in list
		}
		
		System.out.println(			sortedList.stream().sorted(Collections.reverseOrder()).collect(Collectors.toList())   );

	}

}
