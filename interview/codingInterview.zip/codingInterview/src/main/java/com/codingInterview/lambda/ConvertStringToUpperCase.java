package com.codingInterview.lambda;

@FunctionalInterface
interface UpperCaseConversion{
	
	String upperCaseConversion(String s);
}

public class ConvertStringToUpperCase {

	public static void main(String[] args) {

		UpperCaseConversion u= (s) -> s.toUpperCase();
		
		String newString = u.upperCaseConversion("tushar");
		System.out.println(newString);
	}

}
