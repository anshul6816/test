package com.codingInterview.String;

public class ReverseString {

	public static void main(String[] args) {

		
		String name = "Anshul";

		String reverseName = "";

		int len = name.length();
		char ch[] = new char[len-1];

		for (int i = len - 1; i >= 0; i--) {

			reverseName += name.charAt(i);

		}

		System.out.println(reverseName);

		
	}
}
