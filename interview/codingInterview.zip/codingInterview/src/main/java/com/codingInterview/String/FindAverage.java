package com.codingInterview.String;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FindAverage {

	public static void main(String[] args) {
		List<Integer> asList = Arrays.asList(10, 20, 30, 40, 50);

		double asDouble = asList.stream().mapToDouble(Integer::doubleValue).average().getAsDouble();
		
		/*
		 * ALTERNATE METHOD Double collect =
		 * 									asList.stream().collect(Collectors.averagingDouble(Integer::doubleValue));
		 */

		System.out.println(asDouble);
	}
}
