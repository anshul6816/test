
package com.codingInterview.String;

import java.util.LinkedHashMap;
import java.util.Map;

public class Demo {

	public static void main(String[] args) {

		String s = "abcbcsdfabcdaa";
		longestSubstring(s);

	}

	public static void longestSubstring(String s) {
		
		String longestSubString=null;
		int longestSubStringLength=0;
		
		char[] arr= s.toCharArray();
		Map<Character,Integer> m= new LinkedHashMap<>();
		for(int i=0;i<arr.length;i++) {
			
			char ch=  arr[i];
			if( !m.containsKey(ch)) {
				m.put(ch,i);
			}else {
				i=  m.get(ch);
				m.clear();
			}
		}
		
	}
}
