package com.codingInterview.String;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FlatMapExample {

	public static void main(String[] args) {
	
		String[][] myString= new String[][] {{"1","2"},{"3","4"},{"5","6"}};

		List<String> collect = Stream.of(myString).flatMap(Stream::of).collect(Collectors.toList());
		
		System.out.println(collect);
		
		
	}

}
