package com.codingInterview.String;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class PrintlongestStringFromGivenArray {

	public static void main(String[] args) {

		/*
		 * CONVERT ARRAY INTO LIST Integer[] i = new Integer[]{1,5,3,6,4,9,7};
		 * 
		 * System.out.println(Arrays.asList(i));
		 */

		List<String> asList = Arrays.asList("Java", "Python", "C", "Go", "Angular", "Mule", "Java");
		System.out.println("List: " + asList);
		
		// Since Set doesnot contain duplicate value. therefore removing duplicate from list and store in set
		Set<String> removeDuplicateValueFromList = asList.stream().collect(Collectors.toSet());
		System.out.println("Set: " + removeDuplicateValueFromList);

		//Create a Map with Key----> given String and Value-----> String length
		Map<String, Integer> stringValueAndLengthMap = removeDuplicateValueFromList.stream()
																				.collect( Collectors.toMap( s->s, s -> s.length())
																						);
		System.out.println("Map: "+ stringValueAndLengthMap);
		
		//collect the values from map find the longest length
		int longestLength = stringValueAndLengthMap.values().stream()
														  .sorted(Collections.reverseOrder())
														  .findFirst()
														  .get();
		
		
		//Loop through map and print the longest String
		for (Map.Entry<String, Integer> m: stringValueAndLengthMap.entrySet()) {
			
			if(m.getValue()==longestLength)
				System.out.println("Longest String: " + m.getKey());
			
		}
	}

}
