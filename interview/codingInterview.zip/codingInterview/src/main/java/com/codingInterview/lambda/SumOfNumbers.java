package com.codingInterview.lambda;

@FunctionalInterface
interface SumInteger {
	int findSum(int a, int b);
}

public class SumOfNumbers {
public static void main(String[] args) {
	SumInteger sumInteger= (x,y) -> x+y;
	
	System.out.println(sumInteger.findSum(10, 20));
}


}
