package com.codingInterview.String;

public class StringPallindromeCheck {

	
	
	public static void main(String[] args) {

		String name= "dad";
		StringBuffer sb= new StringBuffer();
		sb.append(name);
		
		String reverseName= sb.reverse().toString();
		
		System.out.println("name" + ": " + name);
		System.out.println("Reverse Name" + ": " + reverseName);
		
		if(reverseName.equalsIgnoreCase(name)) {
			
			System.out.println("Both are Equal");
		}
		else {
			
			System.out.println("Both are not Equal");
		}
		
	}

}
