package com.codingInterview.String;

//https://www.hackerrank.com/challenges/java-list/problem?isFullScreen=true
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class HackekrRankListProblem {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter number of elements in List: ");
		int listSize = sc.nextInt();
		sc.nextLine();

		List<Integer> numList = new ArrayList<>();

		for (int i = 0; i < listSize; i++) {
			System.out.print("Enter element " + i + " in List: ");
			numList.add(sc.nextInt());
			sc.nextLine();
		}

		System.out.println(numList);
		System.out.println("Enter number of queries: ");
		int queryCount = sc.nextInt();
		sc.nextLine();
		
		String s= new String();
		int index;
		int value;
		
		for (int i = 1; i <= queryCount; i++) {
		System.out.print("Enter query " + i +": "  );
		s=sc.nextLine();
		
		if(s.equalsIgnoreCase("insert")) {
			System.out.print("Enter index where value has to be inserted: ");
			index= sc.nextInt();
			sc.nextLine();
			
			System.out.print("Enter value to be inserted: ");
			value= sc.nextInt();
			sc.nextLine();
			
			numList.add(index, value);
			System.out.println("New List: " + numList);
		}
		
		if(s.equalsIgnoreCase("delete")) {
			System.out.print("Enter index where value has to be inserted: ");
			index= sc.nextInt();
			sc.nextLine();
				
			numList.remove(index);
			System.out.println("New List: " + numList);
		}
		
		
		
		}
	}

}
