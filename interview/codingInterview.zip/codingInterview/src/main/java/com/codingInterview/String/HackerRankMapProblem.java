package com.codingInterview.String;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class HackerRankMapProblem {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of Entries to be inserted: ");
		int noOfEntries = sc.nextInt();
		sc.nextLine();

		Map<String, Long> phoneBookMap = new HashMap<>();
		for (int i = 1; i <= noOfEntries; i++) {
			System.out.println("Enter Name: ");
			String personName = sc.nextLine();
			System.out.println("Enter Phone Number: ");
			long personContact = sc.nextLong();
			sc.nextLine();

			phoneBookMap.put(personName, personContact);
		}

		System.out.println(phoneBookMap);

		System.out.println("Enter person name to search the records: ");
		String searchPerson = sc.nextLine();

		for (Map.Entry<String, Long> m : phoneBookMap.entrySet()) {

			Set<String> keySet = phoneBookMap.keySet();
			boolean anyMatch = keySet.stream().anyMatch(s -> s.equalsIgnoreCase(searchPerson));	//Check searchPerson is in phoneBook or not
			
			if (anyMatch == true) {
				if (m.getKey().equalsIgnoreCase(searchPerson)) {
					m.getValue();
					System.out.println(m);
				}
			}
			else {
				System.out.println("Record Not Found!!!!!!!1");
				break;
			}
		}

	}

}
