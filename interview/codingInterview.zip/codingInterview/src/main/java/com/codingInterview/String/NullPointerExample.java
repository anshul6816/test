package com.codingInterview.String;

public class NullPointerExample {

	public static NullPointerExample demoMethod() {
		return null;
	}

	public void print(String s) {
		System.out.println(s.toLowerCase());
	}

	public static void main(String[] args) {

		NullPointerExample d = demoMethod();
		try {
		
			d.print("Hi");
		
		} catch (NullPointerException ne) {
			System.out.println("it is a null exception!!!!!!!!!");
		}

	}
}
