package com.codingInterview.String;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class DegreeOfArray {

	public static void main(String[] args) {
		
		int[] numArray= new int[] {1,0,4,6,5,5,5,5,4,4,7,9,7,7,1,1,1,1,1,1,1,3,3,3,3,3,9,9};
		
		List<Integer> numList= new ArrayList();
		
		for(Integer i: numArray) {
			numList.add(i);
		}
		
		System.out.println("List: " + numList);
		Map<Integer, Long> collect = numList.stream()
											.collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		
		Long maxDegreeOfArray = collect.values().stream().max(Long::compare).get();
		Long minDegreeOfArray = collect.values().stream().min(Long::compare).get();	
		
		Map<Integer, Long> elementWithMaxDegree = collect.entrySet().stream()
																			.filter(m -> m.getValue() == maxDegreeOfArray)
																			.collect(Collectors.toMap(k-> k.getKey(), v ->v.getValue()));
		
		Map<Integer, Long> elementWithMinDegree = collect.entrySet().stream()
																			.filter(m -> m.getValue() == minDegreeOfArray)
																			.collect(Collectors.toMap(k-> k.getKey(), v ->v.getValue()));

		System.out.println("Element with max degree: " + elementWithMaxDegree);
		System.out.println("Element with min degree: " +elementWithMinDegree);
	}

}
