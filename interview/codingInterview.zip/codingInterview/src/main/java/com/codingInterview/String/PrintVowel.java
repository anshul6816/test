package com.codingInterview.String;

import java.util.HashSet;
import java.util.Set;

public class PrintVowel {

	public static void main(String[] args) {
		String name="tushar patle";
		name= name.toLowerCase();
		
		Set<Character> vowelList= new HashSet<>();
		Set<Character> consonentList= new HashSet<>();
		int vowelCount=0;
		int consonentCount=0;
		
		for(int i=0;i<name.length();i++) {
			char ch= name.charAt(i);
			
			if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u') {
				
				vowelCount++;
				vowelList.add(ch);
			
		
			}
			
			if((ch !='a' && ch !='e' && ch !='i' && ch !='o' && ch !='u') && (ch >='a' && ch <='z')) {
				consonentCount++;
				consonentList.add(ch);
			}
			
		}
		
		System.out.println("vowel List: " + vowelList + " count: " + vowelCount);
		
		System.out.println("vowel List: " + consonentList + " count: " + consonentCount);

	}
}
