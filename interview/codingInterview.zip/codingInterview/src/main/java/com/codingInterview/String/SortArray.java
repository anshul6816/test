package com.codingInterview.String;

import java.util.Arrays;

public class SortArray {

	public static void main(String[] args) {

		String[] s= new String[] {"Java","Akb","kxc","z2"};
		
		Arrays.sort(s);

		for (int i = 0; i < s.length; i++)   
		{       
		System.out.println(s[i]);   
		}  
		
	}

}
