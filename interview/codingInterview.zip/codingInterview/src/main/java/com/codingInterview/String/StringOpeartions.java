package com.codingInterview.String;

public class StringOpeartions {
	
	public static void main(String[] args) {
		
		String s1="Tushar";
		String s2= new String();
		String s3= new String(s1);
		String s4= new String("Tushar");
		
		System.out.println(s1==s3);
		System.out.println(s1==s4);
		
		System.out.println(s1.equals(s3));
		System.out.println(s1.equals(s4));
		
	}

}
