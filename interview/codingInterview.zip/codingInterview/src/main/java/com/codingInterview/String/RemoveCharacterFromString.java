package com.codingInterview.String;

public class RemoveCharacterFromString {

	public static void main(String[] args) {
		
		String name= "Tushar";
		String charToRemove= "s";
		String newName= name.replaceAll(charToRemove, "");
		System.out.println(newName);
		
	}

}
