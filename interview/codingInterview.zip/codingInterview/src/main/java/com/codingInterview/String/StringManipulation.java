package com.codingInterview.String;

// INPUT-----> abbcdddddzzrrr

//OUTPUT---> a1b2c1d4z2r3

public class StringManipulation {
	public static void main(String[] args) {
		String inputValue = "ddxdsssssvvrrrrlllcvv";
		
		StringBuilder sb = new StringBuilder();
		char[] charArray = inputValue.toCharArray();
		int count = 0;
		char ch2 = 0;
		int j = 0;
		for (int i = 0; i < charArray.length; i = j) {
			char ch1 = charArray[i];
			for (j = i; j < charArray.length; j++) {
				ch2 = charArray[j];
				if (ch1 == ch2) {
					count++;

				} else {

					break;

				}

			}

			String storeString = ch1 + "" + count;
			sb.append(storeString);
			System.out.println(sb);
			count = 0;
		}

	}
}
