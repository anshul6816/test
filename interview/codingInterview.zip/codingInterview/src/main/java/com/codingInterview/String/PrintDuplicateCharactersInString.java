package com.codingInterview.String;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class PrintDuplicateCharactersInString {

	public static void main(String[] args) {

		String s = "Tushar Patle";
		String lowerCaseString= s.toLowerCase();

		Map<Character, Long> duplicateCharMap = lowerCaseString.chars()
												 .mapToObj(c -> (char) c)
												 .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
	
		//------------------------Method 1----------------------------------------
		duplicateCharMap.forEach(

				(key, value) -> {
					if (value > 1) {
						System.out.println(key + " : " + value);
					}

				});
		
		//------------------------Method 2----------------------------------------
		Map<Character, Long> collect = duplicateCharMap.entrySet().stream()
																  .filter(v -> v.getValue() >1)
																  .collect(
																		  	Collectors.toMap(k -> k.getKey(), v -> v.getValue()
																		  ));
		
		System.out.println(collect);
		//--------------------------------------------------------------------------
		
	}

}
