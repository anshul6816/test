package com.codingInterview.String;

import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

public class MaxOccuringCharacter {

	public static void main(String[] args) {
		
		String s= "javta titanic";
		String lowerCaseString= s.toLowerCase();
		
		Map<Character, Long> characterMap = lowerCaseString.chars()
					   .mapToObj(c -> (char)c)
					   .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
					   
		System.out.println(characterMap);
		

		
		//find maximum value 
		Optional<Long> max = characterMap.values().stream().max((i1,i2) -> (i1>i2)?1:(i1<i2)?-1:0);
		//OR ........Optional<Long> max =characterMap.values().stream().max(Long::longValue);
		//get mav value from optional
		Long maxValue = max.get();
		
		
		/*
		 * ALTERNATE METHOD 
		 * 
		 * System.out.println(characterMap.entrySet() .stream()
		 * .filter( x -> x.getValue()==maxValue) .map(c -> c.getKey()).findFirst().get()
		 * );
		 */
		
		//iterate and when value= maxValue, print that character
		characterMap.forEach(

								(key,value) ->  {
													if(value==maxValue) {	
																System.out.println("Max occuring character" + ": " + key);
													}
											    }
							);
	}

}
