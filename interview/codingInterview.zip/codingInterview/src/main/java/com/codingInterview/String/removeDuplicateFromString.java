package com.codingInterview.String;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class removeDuplicateFromString {

	public static void main(String[] args) {
		
		String string = "aabbccdefatafaz";
		
		//--------------------------Method 1---------------------------------
		char[] chars = string.toCharArray();
		Set<Character> charSet = new LinkedHashSet<Character>();
		for (char c : chars) {
		    charSet.add(c);
		}

		StringBuilder sb = new StringBuilder();
		for (Character character : charSet) {
		    sb.append(character);
		}
		
		System.out.println(sb.toString());
		
		//----------------------Method 2------------------------------------
		Set<Character> collect = string.chars().mapToObj(c -> (char)c).collect(Collectors.toSet());
		
		StringBuilder sb1= new StringBuilder();
		for(Character c: collect) {
		
			sb1.append(c);
			
		}
		System.out.println(sb1.toString());
		//........................................................................
	}

}
