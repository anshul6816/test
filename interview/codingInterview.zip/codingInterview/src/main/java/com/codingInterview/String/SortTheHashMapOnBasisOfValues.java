package com.codingInterview.String;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

public class SortTheHashMapOnBasisOfValues {
	public static void main(String[] args) {

		HashMap<Integer, String> m= new HashMap<Integer,String>();
		m.put(50, "Tejas");
		m.put(80, "Akila");
		m.put(10, "Diva");
		m.put(20, "Aarti");
		m.put(40, "Tushar");
		m.put(30, "Yatesh");

		//---------------------------------METHOD 1-------------------------------------------------------------------
		Map<Integer, String> collect = m.entrySet().stream()
                .sorted(Entry.comparingByValue())
                .collect(Collectors.toMap(Entry::getKey, Entry::getValue, (oldValue,  newValue) ->oldValue, LinkedHashMap::new));
		

		
		System.out.println(collect);
		
		//----------------------------------------------------------------------------------------------------
		
		//---------------------------------METHOD 2-------------------------------------------------------------------
		HashMap<Integer, String> sortByValue = sortByValue(m);
		System.out.println(sortByValue);
	
	}
	
	public static HashMap<Integer,String> sortByValue(HashMap<Integer, String> hm)
    {
        // Create a list from elements of HashMap
        List<Map.Entry<Integer,String> > list = new ArrayList<>( );
        list.addAll(hm.entrySet());
        
        System.out.println(list);
 
        // Sort the list using lambda expression
        Collections.sort(
            list,
            (i1,
             i2) -> i1.getValue().compareTo(i2.getValue()));
 
        // put data from sorted list to hashmap
        HashMap<Integer,String> temp = new LinkedHashMap<Integer,String>();
        for (Map.Entry<Integer,String> aa : list) {
            temp.put(aa.getKey(), aa.getValue());
        }
        return temp;
    }
}
