package com.codingInterview.String;

public class JavaStringTokens {

	public static void main(String[] args) {
		String s = "He is a very very good boy, isn't he?";
		String[] split = s.split("[ !,?._'@]+");    //regex to exclude character present inside []. Split string using regex

		for (String s1 : split) {
			System.out.println(s1);
		}
	}

}
