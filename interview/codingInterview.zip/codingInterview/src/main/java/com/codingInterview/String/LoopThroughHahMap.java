package com.codingInterview.String;

import java.util.HashMap;
import java.util.Map;

public class LoopThroughHahMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashMap<Integer, String> m= new HashMap<Integer,String>();
		m.put(2,"Hi");
		m.put(3, "Welcome");
		m.put(1, "to");
		m.put(4,"India");
		
		
		for(Map.Entry<Integer,String> mapElement : m.entrySet()) {
			
			mapElement.getKey();
		
			mapElement.getValue();
		}
		
		System.out.println(m.get(3).hashCode());		// to check hashcode
		
	}

}
