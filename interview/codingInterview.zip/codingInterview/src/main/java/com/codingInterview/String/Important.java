package com.codingInterview.String;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/*
 * 			INPUT---> ["Anshul#3", "Tushar#1", "anshul#4", "akila#1", "tushar#9"]
 * 
 * 			OUTPUT---> {anshul:7, tushar:10, akila:1}
 * 
 * 
 * 
 * */

public class Important {

	public static void main(String[] args) {
		List<String> myList= Arrays.asList("Anshul#3", "Tushar#1", "anshul#4", "akila#1", "tushar#9");
	Set<String> charSet= new LinkedHashSet<>();
	List<Integer> intSet= new ArrayList<>();
	String[] splitString=null;
	for(String s:myList) {
		splitString= s.split("#"); 
	}

	dsfbhdfht rt
	}
}
