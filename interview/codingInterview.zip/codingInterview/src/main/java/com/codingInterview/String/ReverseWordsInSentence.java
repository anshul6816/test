package com.codingInterview.String;

import java.util.Stack;

// inputs-----> This is the toy
//Output------> toy the is this

public class ReverseWordsInSentence {

	public static void main(String[] args) {

		String s = "This is the toy";
		String[] arr = s.split(" ");

		StringBuffer sb = new StringBuffer();

		Stack<String> stack = new Stack<>();
		int len = s.length();

		for (int i = 0; i < arr.length; i++) {

			stack.push(arr[i]);
		}

		for (int i = 0; i < arr.length; i++) {

			String temp = stack.pop();
			sb.append(temp + " ");

		}
		System.out.println(sb.toString());

	}

}
