package com.codingInterview.String;

import java.util.LinkedHashMap;
import java.util.Map;


// https://www.youtube.com/watch?v=ocBU0tKwX1g

// Input-----> abcbcsdfabcdaa
// Output----> bcsdfa: 6

public class LongestSubstringWithoutRepeatingCharacters {

	public static void main(String[] args) {

		String s = "abcbcsdfabcdaa";
		longestSubstring(s);

	}

	public static void longestSubstring(String s) {

		String longestSubString = null;
		int longestSubStringLength = 0;

		char[] arr = s.toCharArray();

		Map<Character, Integer> map = new LinkedHashMap<>();
		for (int i = 0; i < arr.length; i++) {
			char ch = arr[i];
			if (!map.containsKey(ch)) {
				map.put(ch, i);
			} else {
				i = map.get(ch);
				map.clear();
			}

			if (map.size() > longestSubStringLength) {
				longestSubString = map.keySet().toString();
				longestSubStringLength = map.size();
			}
		}

		System.out.println("longestSubString: " + longestSubString);
		System.out.println("longestSubStringLength: " + longestSubStringLength);
	}
}
