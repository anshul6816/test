package com.codingInterview.String;

public class RemoveWhiteSpace {

	public static void main(String[] args) {

		String name= "Tushar Patle sac sdf ewkfh";
		String newName= name.replaceAll(" ", "");
		System.out.println(newName);
	}

}
