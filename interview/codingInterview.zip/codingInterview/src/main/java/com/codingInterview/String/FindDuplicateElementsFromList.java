package com.codingInterview.String;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FindDuplicateElementsFromList {
	
	public static void main(String[] args) {
		
		List<String> asList = Arrays.asList("Java", "Python", "C", "Go", "Angular", "Mule","Java","Python");
		
		Set<String> storeDuplicateElements= new HashSet();
		
		
		//----------------------------------METHOD 1--------------------------------------------------------------
		List<String> collectDuplicateElements = asList.stream()
				.filter(e -> !storeDuplicateElements.add(e))
				.collect(Collectors.toList());
		
		//----------------------------------METHOD 2---------------------------------------------------------------
		Map<String, Long> collectMap = asList.stream()
											 .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		
		Map<String, Long> duplicateElementMap = collectMap.entrySet().stream()
																	 .filter(m -> m.getValue() >1)
																	 .collect(
																			 	Collectors.toMap(k -> k.getKey(), v ->v.getValue()
																			 ));
		//--------------------------------------------------------------------------------------------------------	
		
		System.out.println(collectDuplicateElements);
		
	}

}
