package com.codingInterview.String;

import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.stream.Collectors;

public class FindSumOfEvenAndOddNumbersInList {

	public static void main(String[] args) {
		List<Integer> asList = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
		int evenSum = asList.stream().filter(n -> n % 2 == 0).reduce(Integer::sum).get();

		int oddSum = asList.stream().filter(n -> n % 2 != 0).reduce(Integer::sum).get();

		System.out.println("evenSum: " + evenSum);
		System.out.println("oddSum: " + oddSum);

		
		
		// ...................Method 2..........................
//		IntSummaryStatistics sumEven = asList.stream().filter(n -> n % 2 == 0)
//				.collect(Collectors.summarizingInt(Integer::intValue));
//		long eSum = sumEven.getSum();
//		IntSummaryStatistics sumOdd = asList.stream().filter(n -> n % 2 != 0)
//				.collect(Collectors.summarizingInt(Integer::intValue));
//		long oSum = sumOdd.getSum();
//		System.out.println(eSum);
//		System.out.println(oSum);
		//....................................................................
	}

}
