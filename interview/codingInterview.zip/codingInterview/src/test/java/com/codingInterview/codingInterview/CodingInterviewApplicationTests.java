package com.codingInterview.codingInterview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingInterviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
